#ifndef FPIXEL_H

#define FPIXEL_H
typedef struct
{
    float rgb[3];
} FPixel;

#endif // FPIXEL_H
