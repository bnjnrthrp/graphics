#ifndef LIGHTING_H

#define LIGHTING_H

typedef struct Lighting
{
    int nLights;
} Lighting;
#endif // LIGHTING_H
