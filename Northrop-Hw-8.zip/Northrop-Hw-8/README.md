Name: Benjamin Northrop
Hwk 8: Z-Buffer Shading
Travel Days: None
Operating System: Windows 11 x64 bit
IDE: VS Code Version: 1.90.1 (user setup)
